# 2nd Wave based on official theme Wave

2nd Wave is a [Ghost](https://github.com/TryGhost/Ghost) theme dedicated to podcasters based on [Wave](https://github.com/TryGhost/Wave/).


## Copyright & License

Copyright (c) 2013-2023 Ghost Foundation - Released under the [MIT license](LICENSE).
